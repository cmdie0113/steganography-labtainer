#!/usr/bin/env python3

import json

MARKER = b'<<MV_DATA_START>>\n'

def bits_to_text(bits):

    chars = []

    for i in range(0, len(bits), 8):

        byte = bits[i:i+8]

        if len(byte) < 8:
            continue

        chars.append(chr(int(byte, 2)))

    return ''.join(chars)

def decode():

    try:

        with open('stego_video_dir.webm', 'rb') as f:

            data = f.read()

    except FileNotFoundError:

        print("[-] stego_video_dir.webm not found")
        return

    idx = data.find(MARKER)

    if idx == -1:

        print("[-] Hidden metadata not found")
        return

    hidden_json = data[idx + len(MARKER):]

    try:

        metadata = json.loads(hidden_json.decode())

    except:

        print("[-] Failed to parse metadata")
        return

    bits = ""

    for item in metadata:

        if item["predictor"] == "nearest":
            bits += "0"

        else:
            bits += "1"

    secret = bits_to_text(bits)

    print("[+] Hidden message recovered:")
    print(secret)

if __name__ == "__main__":
    decode()
